package com.javanauta.agendador_horarios;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AgendadorHorariosApplicationTests {

	@Test
	void contextLoads() {
	}

}
