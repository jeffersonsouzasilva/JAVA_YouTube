-- ============================================
-- alunos
-- ============================================
CREATE TABLE alunos (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(150) NOT NULL,
    data_nascimento DATE,
    sexo VARCHAR(1),
    telefone VARCHAR(30),
    celular VARCHAR(30),
    email VARCHAR(150),
    observacao TEXT,
    endereco VARCHAR(150),
    numero VARCHAR(20),
    complemento VARCHAR(100),
    bairro VARCHAR(100),
    cidade VARCHAR(100),
    estado VARCHAR(20),
    cep VARCHAR(20),
    criado_em TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    atualizado_em TIMESTAMP NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT chk_alunos_sexo CHECK (sexo IN ('M','F'))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================
-- modalidades
-- ============================================
CREATE TABLE modalidades (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100) NOT NULL UNIQUE,
    ativo BOOLEAN NOT NULL DEFAULT TRUE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================
-- graduacao
-- ============================================
CREATE TABLE graduacao (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    modalidade_id BIGINT NOT NULL,
    nome VARCHAR(100) NOT NULL,
    CONSTRAINT fk_graduacao_modalidade
        FOREIGN KEY (modalidade_id) REFERENCES modalidades(id),
    CONSTRAINT uq_graduacao UNIQUE (modalidade_id, nome)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================
-- planos
-- ============================================
CREATE TABLE planos (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    modalidade_id BIGINT NOT NULL,
    nome VARCHAR(100) NOT NULL,
    valor_mensal NUMERIC(10,2) NOT NULL,
    ativo BOOLEAN NOT NULL DEFAULT TRUE,
    CONSTRAINT fk_planos_modalidade
        FOREIGN KEY (modalidade_id) REFERENCES modalidades(id),
    CONSTRAINT uq_planos UNIQUE (modalidade_id, nome),
    CONSTRAINT chk_planos_valor CHECK (valor_mensal >= 0)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================
-- matriculas
-- ============================================
CREATE TABLE matriculas (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    aluno_id BIGINT NOT NULL,
    data_matricula DATE NOT NULL DEFAULT (CURRENT_DATE),
    dia_vencimento INT NOT NULL,
    data_encerramento DATE,
    status VARCHAR(20) NOT NULL DEFAULT 'ATIVA',
    CONSTRAINT fk_matriculas_aluno
        FOREIGN KEY (aluno_id) REFERENCES alunos(id),
    CONSTRAINT chk_matriculas_dia CHECK (dia_vencimento BETWEEN 1 AND 31),
    CONSTRAINT chk_matriculas_status
        CHECK (status IN ('ATIVA', 'ENCERRADA', 'CANCELADA'))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================
-- matriculas_modalidades
-- ============================================
CREATE TABLE matriculas_modalidades (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    matricula_id BIGINT NOT NULL,
    modalidade_id BIGINT NOT NULL,
    graduacao_id BIGINT NOT NULL,
    plano_id BIGINT NOT NULL,
    data_inicio DATE NOT NULL DEFAULT (CURRENT_DATE),
    data_fim DATE,
    CONSTRAINT fk_mm_matricula
        FOREIGN KEY (matricula_id) REFERENCES matriculas(id),
    CONSTRAINT fk_mm_modalidade
        FOREIGN KEY (modalidade_id) REFERENCES modalidades(id),
    CONSTRAINT fk_mm_graduacao
        FOREIGN KEY (graduacao_id) REFERENCES graduacao(id),
    CONSTRAINT fk_mm_plano
        FOREIGN KEY (plano_id) REFERENCES planos(id),
    CONSTRAINT uq_mm UNIQUE (matricula_id, modalidade_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================
-- faturas_matriculas
-- ============================================
CREATE TABLE faturas_matriculas (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    matricula_id BIGINT NOT NULL,
    data_vencimento DATE NOT NULL,
    valor NUMERIC(10,2) NOT NULL,
    data_pagamento TIMESTAMP NULL,
    data_cancelamento DATE,
    status VARCHAR(20) NOT NULL DEFAULT 'ABERTA',
    CONSTRAINT fk_faturas_matricula
        FOREIGN KEY (matricula_id) REFERENCES matriculas(id),
    CONSTRAINT chk_faturas_valor CHECK (valor >= 0),
    CONSTRAINT chk_faturas_status
        CHECK (status IN ('ABERTA', 'PAGA', 'CANCELADA', 'VENCIDA')),
    CONSTRAINT uq_faturas UNIQUE (matricula_id, data_vencimento)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================
-- assiduidade
-- ============================================
CREATE TABLE assiduidade (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    matricula_id BIGINT NOT NULL,
    data_entrada TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    data_saida TIMESTAMP NULL,
    CONSTRAINT fk_assiduidade_matricula
        FOREIGN KEY (matricula_id) REFERENCES matriculas(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;