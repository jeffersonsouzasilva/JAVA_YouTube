package dobackaofront.estrutura;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EstruturaApplication {

	public static void main(String[] args) {
		SpringApplication.run(EstruturaApplication.class, args);
	}

}
