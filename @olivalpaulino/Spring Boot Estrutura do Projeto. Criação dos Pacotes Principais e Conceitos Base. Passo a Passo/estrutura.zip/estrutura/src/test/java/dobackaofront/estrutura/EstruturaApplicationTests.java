package dobackaofront.estrutura;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EstruturaApplicationTests {

	@Test
	void contextLoads() {
	}

}
